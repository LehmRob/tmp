# HelloServer

This server is a example for using the boost asio library for a tcp server.
The example application will be a little chat server. The client can connect
to the server and can broadcast messages to all connected clients.
